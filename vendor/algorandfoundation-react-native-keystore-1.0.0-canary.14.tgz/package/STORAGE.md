# On-disk storage format

Authoritative contract for what this package persists on device, aimed at a
native (Kotlin/Swift) implementer that needs to read or write the same MMKV
instance — most notably the passkey autofill credential provider, which runs
in a separate process from the React Native app.

## MMKV instance

- **id**: `"keystore"`
- **mode**: `"multi-process"` (`react-native-mmkv`'s `createMMKV({ id: "keystore", mode: "multi-process" })`, see `src/storage/state.ts`). Multi-process mode is required because the native credential provider writes into the same file from outside the RN process.

All keys in this instance fall into exactly two live prefixes, plus a legacy,
soon-to-be-empty flat layout kept only for reading/adopting old records:

| Prefix             | Contents                                                    |
| ------------------ | ----------------------------------------------------------- |
| `k/<id>`           | Plaintext JSON metadata for key `<id>` (current layout)     |
| `m/<id>`           | Sealed (encrypted) material for key `<id>` (current layout) |
| `<id>` (no prefix) | **Legacy**: one sealed blob with both metadata and material |

`<id>` is an opaque string (a `crypto.randomUUID()` by default). It never
itself starts with `k/` or `m/`.

## Metadata (`k/<id>`)

Written by `putMeta`/`serializeKey` in `src/storage/driver.ts`, read by
`getMeta`/`listMeta`. The value is a **plaintext** JSON-serialized `Key`
object (see `@algorandfoundation/keystore-core`'s `types/core.ts`):

```jsonc
{
  "id": "…",
  "type": "hd-root-key", // KeyType — see "Material by key type" below
  "algorithm": "raw", // e.g. "raw" | "EdDSA" | "P256" | "Falcon-1024" | …
  "extractable": false,
  "keyUsages": ["deriveBits", "deriveKey"],
  "publicKey": { "$u8": "<base64>" }, // present only when the type has a public key
  "format": "pkcs8", // present only for byte-only asymmetric keys
  "metadata": {
    /* type-specific, plaintext, non-secret fields — see below */
  },
  "version": 1,
}
```

Any `Uint8Array` field (currently only `publicKey`) is wrapped as
`{ "$u8": "<base64>" }` rather than serialized as a plain array, so it
round-trips exactly.

**This is a change from the legacy flat record, where the entire record
(including the private material) was sealed as one blob.** Metadata is now
stored in **plaintext** so the reactive store can hydrate the full key list
(`listMeta()`) on every launch without a master-key read or a biometric
prompt for every record — hydration only touches Keychain when a
material-touching operation (`sign`, `export`, …) is actually invoked.

Because metadata is plaintext, **secret material (private keys, seeds,
passphrases, raw entropy) must never be written into a `Key`'s `metadata`
field.** The core engine already enforces this at the call sites that build
`metadata` (e.g. it strips any inline `seed`/`entropy`/`passphrase`/`salt`
before persisting); only public, non-secret descriptors belong there:
`scheme`, `parentKeyId`, derivation `path`/`bip44Path`, passkey
`origin`/`userHandle`/`counter`, `storage` (`"bytes" | "cryptokey" | "none"`),
and similar.

## Material (`m/<id>`)

Written/read by `put`/`use` in `src/storage/driver.ts`. Only present for keys
whose metadata has `metadata.storage !== "none"` (see the table below — HD-
and passkey-_derived_ keys hold no material of their own). The value is the
sealed envelope (below) wrapping `base64(<raw bytes>)` — i.e. the plaintext
that gets sealed is itself a base64 string of the key's raw bytes, not the
raw bytes directly.

## Sealed envelope

Produced by `sealData` / consumed by `openData` in `src/storage/crypto.ts`.
Used for both `m/<id>` material and (historically) the legacy flat records.

- **Cipher**: AES-256-GCM
- **IV**: 96 bits (12 bytes), freshly random per seal
- **Tag**: GCM's 128-bit authentication tag, **appended to the ciphertext**
  (this is how WebCrypto Subtle's `encrypt`/`decrypt` work — there is no
  separate tag output/input)
- **Encoding**: every binary field is base64 (RFC 4648, standard alphabet)

Current shape:

```json
{ "iv": "<base64, 12 bytes>", "content": "<base64, ciphertext||tag>" }
```

### Legacy envelope variant

Older payloads (written by `react-native-quick-crypto`'s `createCipheriv`,
which surfaces the GCM tag separately) used:

```json
{ "iv": "<base64, 12 bytes>", "tag": "<base64, 16 bytes>", "content": "<base64, ciphertext only>" }
```

`openData` reads **both** shapes: when a `tag` field is present it
concatenates `content || tag` before calling `subtle.decrypt`; otherwise it
passes `content` straight through, since the tag is already appended. `sealData`
only ever **writes** the current `{iv, content}` shape — old records are
transparently upgraded to the new shape the next time they are resealed (e.g.
on adoption, see below), never rewritten in place otherwise.

A native implementer only needs to **write** the current shape; supporting
the legacy read path is optional and only useful if reading historical
records directly (bypassing this package's adoption pass).

## Material by key type

The exact bytes sealed under `m/<id>` depend on `type`/`algorithm`, derived
from `../core/src/create.ts`. React Native always uses the byte-only code
path (`capabilities.nativeCryptoKey === false`), never a native `CryptoKey`.

| `type`                                       | `algorithm` / `metadata.scheme`                             | `m/<id>` material                                                                                                                                                        | Has own material? |
| -------------------------------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------- |
| `seed` / `hd-seed`                           | `raw`                                                       | Raw BIP39/Algo25 **entropy** (16 or 32 bytes) — _not_ the 64-byte derived seed; that is computed just-in-time from entropy via the BIP39/Algo25 shim.                    | yes               |
| `hd-root-key`                                | `raw`, `metadata.scheme: "bip32-ed25519"` (XHD root)        | The 96-byte BIP32-Ed25519 **root key** produced by `xhd.fromSeed(seed)` — this is a root key, not a raw seed and not a single private-key scalar.                        | yes               |
| `hd-root-key`                                | `P256`, `metadata.scheme: "pbkdf2-p256"` (passkey main key) | The PBKDF2-HMAC-SHA512-derived **main key** bytes (`dp256.genDerivedMainKey(...)`), keyed off the parent seed/entropy.                                                   | yes               |
| `hd-derived-ed25519`                         | `EdDSA`                                                     | **None.** Metadata-only (`metadata.storage: "none"`); re-derived on demand from the parent `hd-root-key`'s material + `metadata.bip44Path`/`derivationType`.             | no                |
| `hd-derived-p256`                            | `P256`                                                      | **None.** Metadata-only (`metadata.storage: "none"`); re-derived on demand from the parent PBKDF2 main key + `metadata.origin`/`userHandle`/`counter`.                   | no                |
| `ed25519`                                    | `EdDSA`                                                     | The private key exported as **PKCS#8 DER** (`format: "pkcs8"`), _not_ a raw 32-byte seed/scalar — React Native always takes the byte-only (non-native-`CryptoKey`) path. | yes               |
| `falcon-1024`                                | `Falcon-1024`                                               | The Falcon-1024 private key bytes as exported by the binding, seed-derived when `params.seed` was supplied.                                                              | yes               |
| any other host algorithm (`generateHostKey`) | e.g. `ECDSA`/`RSA`                                          | PKCS#8 DER for asymmetric keys (`format: "pkcs8"`), or raw bytes for a symmetric key (`format: "raw"`).                                                                  | yes               |

**Summary for the XHD/passkey distinction called out above:** an XHD
`hd-root-key` holds a **root key** (96 bytes, output of BIP32-Ed25519
`fromSeed`), never a bare seed and never a single Ed25519 private-key scalar;
a `hd-derived-p256` passkey holds **no material at all** — only its P-256
public key and the domain descriptor needed to re-derive the private scalar
from the pbkdf2-p256 main key on demand.

## Legacy flat layout (for reference only)

Before the `k/`+`m/` split, `src/storage/state.ts`'s `commit()` wrote **one**
sealed record per key at the bare `<id>` key: the sealed envelope (current or
legacy shape, see above) wrapping `encode(keyData)`, where `encode()` is a
JSON serialization of the full `KeyData` (`Key` + `privateKey`/`seed`) with
`Uint8Array` fields wrapped as `{ "$u8": "<base64>" }`. An even older
sub-variant (still transparently read by `decode()`) instead wrapped the
JSON as `base64url(utf8(json))` with byte fields stored as plain number
arrays. Both are "flat": metadata and material are not separable without
first decrypting the whole record, and neither is visible to `listMeta()`
(which only scans `k/`).

Two writers still produce flat records today:

- the deprecated `commit()`/`fetchSecret()`/`removeSecret()` helpers, still
  called directly by some apps for in-place metadata edits;
- the native Android/iOS passkey credential provider, which writes
  credentials straight into this MMKV instance from a separate process using
  this same flat shape (it does not go through this package's API at all).

## Migration rules

1. **Adoption is additive and non-destructive.** A flat `<id>` record is only
   ever converted to `k/<id>` + `m/<id>`; it is never merged into or
   overwritten by an existing `k/`/`m/` pair (a flat id and a `k/`/`m/` id are
   never expected to collide, since ids are random).
2. **Split point.** `decode()` the flat blob, then split its fields into: (a)
   the **material** — `privateKey` if present, else `seed` — and (b)
   everything else, which becomes the `k/<id>` metadata verbatim (serialized
   with the same `{ "$u8": … }` convention `putMeta` uses).
3. **Re-seal, don't reuse.** The material is re-sealed fresh (new random IV,
   current `{iv, content}` envelope) as `base64(material)` under `m/<id>`; the
   flat record's own envelope (possibly the legacy `{iv, tag, content}` shape)
   is never copied forward.
4. **Ordering / atomicity.** `m/<id>` is written before `k/<id>`, and the flat
   `<id>` record is only `remove()`d after **both** writes succeed — so a
   crash mid-adoption can at worst leave a stray `m/`/`k/` entry next to an
   untouched flat record (safe to retry), never a missing record.
5. **Records with no recoverable material are skipped, not deleted.** A
   record that fails to decrypt (wrong/absent master key content, corrupt
   ciphertext) or decrypts to something with neither `privateKey` nor `seed`
   (e.g. a native credential protected by a biometric cipher this package
   cannot open) is left as-is and reported, so it is retried on the next pass
   instead of being silently lost.
6. **Idempotent.** Once adopted, a record lives under `k/`/`m/` and is
   excluded from the flat scan (which only considers ids under neither
   prefix), so re-running the pass is always a cheap no-op for it.
7. **The master key is read at most once per pass, and only when there is at
   least one flat candidate.** A fresh install has neither flat records nor a
   master key; treating "no master key" as "nothing to migrate" (rather than
   an error) when there are candidate ids avoids ever prompting the user at
   startup for a device that has nothing to migrate. Any other master-key
   failure (e.g. a cancelled/failed interactive unlock) is surfaced to the
   caller.
8. **Legacy passkey flagging still runs after adoption**, so passkeys that
   arrive via a freshly-adopted flat record are covered by the same
   `needs-migration` check as passkeys already stored under `k/`.

See `src/storage/legacy.ts` (`adoptLegacyRecords`) for the implementation and
`src/engine.ts` for how it is wired into `createReactNativeKeyStore` (via the
driver's `ready` phase) and exposed again through `reload()`.
